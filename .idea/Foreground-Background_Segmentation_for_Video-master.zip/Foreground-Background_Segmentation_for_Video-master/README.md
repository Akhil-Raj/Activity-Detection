# Foreground/Background Segmentation for Video

Notes:

1. The code for graph cut is mainly from [OpenCV](https://github.com/opencv/opencv/blob/master/modules/imgproc/src/grabcut.cpp).
2. The program is not stable. (It can crash when processing some frame.)

Reference: Ting Yu, Cha Zhang, Michael Cohen, Yong Rui and Ying Wu. Monocular Video Foreground/Background Segmentation by Tracking Spatial-Color Gaussian Mixture Models. IEEE Workshop on Motion and Video Computing (WMVC’07).